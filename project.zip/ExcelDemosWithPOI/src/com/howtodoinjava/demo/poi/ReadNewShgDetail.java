package com.howtodoinjava.demo.poi;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ReadNewShgDetail {

	public static String convertDoubleTostring(Double e1Val) {
		
		//Double e1Val = e1Val.getNumericCellValue();
		BigDecimal bd = new BigDecimal(e1Val.toString());
		long lonVal = bd.longValue();
		System.out.println(lonVal);
		return String.valueOf(lonVal);
	}
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		try
		{
			FileInputStream file = new FileInputStream(new File("new_shg_detail.xlsx"));

			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			//Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			//Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			
			//List to contain data
			List<ShgData> listData = new ArrayList<ShgData>();
			int countSkipTitleLine = 0 ;
			while (rowIterator.hasNext()) 
			{
				Row row = rowIterator.next();
				//For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				ShgData data = new ShgData();
				int count = 0;
				
				
				if(countSkipTitleLine == 0) {
					countSkipTitleLine++;
					continue;
				}
				while (cellIterator.hasNext()) 
				{   
					
					Cell cell = cellIterator.next();
					//Check the cell type and format accordingly

					
					
					switch (cell.getCellType()) 
					{
						case Cell.CELL_TYPE_FORMULA:
						
						switch (count) {
						
						case 0: data.setState_code(Double.toString(cell.getNumericCellValue())); break;
						case 2: data.setDistrict_code(Double.toString(cell.getNumericCellValue())); break;
						case 6: data.setGp_code(Double.toString(cell.getNumericCellValue())); break;
						case 8: data.setVillage_code(Double.toString(cell.getNumericCellValue())); break;	
						case 4: data.setBlock_code(Double.toString(cell.getNumericCellValue())); break;
						case 10: data.setShg_code(Double.toString(cell.getNumericCellValue())); break;
						
						}
						
						
						System.out.print(cell.getNumericCellValue() + "\t");
						break;
						case Cell.CELL_TYPE_NUMERIC:
							
							switch (count) {
							
							case 0: data.setState_code(convertDoubleTostring(cell.getNumericCellValue())); break;
							case 2: data.setDistrict_code(convertDoubleTostring(cell.getNumericCellValue())); break;
							case 6: data.setGp_code(convertDoubleTostring(cell.getNumericCellValue())); break;
							case 8: data.setVillage_code(convertDoubleTostring(cell.getNumericCellValue())); break;	
							case 4: data.setBlock_code(convertDoubleTostring(cell.getNumericCellValue())); break;
							case 10: data.setShg_code(convertDoubleTostring(cell.getNumericCellValue())); break;
							
							}
							
							
							System.out.print(cell.getNumericCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_STRING:
							switch (count) {
							
							case 1: data.setState_name(cell.getStringCellValue()); break;
							case 3: data.setDistrict_name(cell.getStringCellValue()); break; 
							
							case 5: data.setBlock_name(cell.getStringCellValue()); break;
							case 7: data.setGrampanchayat_name(cell.getStringCellValue()); break;
							
							
							case 9: data.setVillage_name(cell.getStringCellValue()); break;
							case 11: data.setGroup_name(cell.getStringCellValue()); break;
							}
					
							System.out.print(cell.getStringCellValue() + "\t");
							break;
					}
					count++;	
				}
				System.out.println("");
				listData.add(data);
				
			}
			System.out.println("*******" +listData.get(0).getVillage_code());
			file.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	
	}

}
