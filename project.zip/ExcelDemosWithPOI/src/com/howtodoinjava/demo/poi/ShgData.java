package com.howtodoinjava.demo.poi;

public class ShgData {
	/*
	private Double stateCode;
	private String state_name;
	private Double district_code;
	private String district_name;
	private String block_code;
	private String block_name;
	private Double gp_code;
	private String grampanchayat_name;
	private Double village_code;
	private String village_name;
	private Double shg_code;
	private String group_name;
	public Double getStateCode() {
		return stateCode;
	}
	public void setStateCode(Double stateCode) {
		this.stateCode = stateCode;
	}
	public String getState_name() {
		return state_name;
	}
	public void setState_name(String state_name) {
		this.state_name = state_name;
	}
	public Double getDistrict_code() {
		return district_code;
	}
	public void setDistrict_code(Double district_code) {
		this.district_code = district_code;
	}
	public String getDistrict_name() {
		return district_name;
	}
	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}
	public String getBlock_code() {
		return block_code;
	}
	public void setBlock_code(String block_code) {
		this.block_code = block_code;
	}
	public String getBlock_name() {
		return block_name;
	}
	public void setBlock_name(String block_name) {
		this.block_name = block_name;
	}
	public Double getGp_code() {
		return gp_code;
	}
	public void setGp_code(Double gp_code) {
		this.gp_code = gp_code;
	}
	public String getGrampanchayat_name() {
		return grampanchayat_name;
	}
	public void setGrampanchayat_name(String grampanchayat_name) {
		this.grampanchayat_name = grampanchayat_name;
	}
	public Double getVillage_code() {
		return village_code;
	}
	public void setVillage_code(Double village_code) {
		this.village_code = village_code;
	}
	public String getVillage_name() {
		return village_name;
	}
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}
	public Double getShg_code() {
		return shg_code;
	}
	public void setShg_code(Double shg_code) {
		this.shg_code = shg_code;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	
	@Override
	public String toString() {
		return "ShgData [stateCode=" + stateCode + ", state_name=" + state_name + ", district_code=" + district_code
				+ ", district_name=" + district_name + ", block_code=" + block_code + ", block_name=" + block_name
				+ ", gp_code=" + gp_code + ", grampanchayat_name=" + grampanchayat_name + ", village_code="
				+ village_code + ", village_name=" + village_name + ", shg_code=" + shg_code + ", group_name="
				+ group_name + "]";
	}
	
*/
	   private String state_code;
	   private String state_name;
	   private String district_code;
	   private String district_name;
	   private String block_code;
	   private String block_name;
	   private String gp_code;
	   private String grampanchayat_name;
	   private String village_code;
	   private String village_name;
	   private String shg_code;
	   private String group_name;
	public String getState_code() {
		return state_code;
	}
	public void setState_code(String state_code) {
		this.state_code = state_code;
	}
	public String getState_name() {
		return state_name;
	}
	public void setState_name(String state_name) {
		this.state_name = state_name;
	}
	public String getDistrict_code() {
		return district_code;
	}
	public void setDistrict_code(String district_code) {
		this.district_code = district_code;
	}
	public String getDistrict_name() {
		return district_name;
	}
	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}
	public String getBlock_code() {
		return block_code;
	}
	public void setBlock_code(String block_code) {
		this.block_code = block_code;
	}
	public String getBlock_name() {
		return block_name;
	}
	public void setBlock_name(String block_name) {
		this.block_name = block_name;
	}
	public String getGp_code() {
		return gp_code;
	}
	public void setGp_code(String gp_code) {
		this.gp_code = gp_code;
	}
	public String getGrampanchayat_name() {
		return grampanchayat_name;
	}
	public void setGrampanchayat_name(String grampanchayat_name) {
		this.grampanchayat_name = grampanchayat_name;
	}
	public String getVillage_code() {
		return village_code;
	}
	public void setVillage_code(String village_code) {
		this.village_code = village_code;
	}
	public String getVillage_name() {
		return village_name;
	}
	public void setVillage_name(String village_name) {
		this.village_name = village_name;
	}
	public String getShg_code() {
		return shg_code;
	}
	public void setShg_code(String shg_code) {
		this.shg_code = shg_code;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	   
	   
	   
	   
	   
	   
	
	

}
